import Vue from 'vue'
import THREE from 'three'
import App from './components/THREEApp.vue'

new Vue({
  el: '#app',
  render: h => h(App)
})
