import Vue from 'vue'
import App from './components/SQRApp.vue'

new Vue({
  el: '#app',
  render: h => h(App)
})
